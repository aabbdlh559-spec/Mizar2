package com.example.zira;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 4102;
    private EditText input;
    private TextView output;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(40, 40, 40, 40);

        TextView title = new TextView(this);
        title.setText("ميزار\nكيبورد ومترجم لغتنا السرية");
        title.setTextSize(22); title.setGravity(Gravity.CENTER); root.addView(title);

        TextView tip = new TextView(this);
        tip.setText("لفك رسالة وصلتك: انسخها، وبعدها افتح الكيبورد لتظهر الترجمة.");
        tip.setPadding(0, 16, 0, 16); root.addView(tip);
        root.addView(button("1) تفعيل الكيبورد", v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))));
        root.addView(button("2) اختيار الكيبورد", v -> ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker()));
        root.addView(button("🔍 تشغيل عدسة ميزار العائمة", v -> startLensSetup()));
        root.addView(button("إيقاف عدسة ميزار", v -> stopService(new Intent(this, MizarLensService.class))));

        input = new EditText(this);
        input.setHint("اكتب أو الصق النص هنا"); input.setMinLines(3);
        input.setGravity(Gravity.TOP | Gravity.START); root.addView(input);
        root.addView(button("عربي ← لغتنا", v -> output.setText(ZiraCodec.encodeText(input.getText().toString()))));
        root.addView(button("لغتنا ← عربي", v -> output.setText(ZiraCodec.decodeText(input.getText().toString()))));
        output = new TextView(this);
        output.setTextSize(18); output.setTextIsSelectable(true); output.setPadding(0, 24, 0, 24); root.addView(output);
        root.addView(button("نسخ النتيجة", v -> {
            ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("mizar", output.getText()));
            Toast.makeText(this, "تم النسخ", Toast.LENGTH_SHORT).show();
        }));
        root.addView(button("للتواصل مع المطور", v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/967739656992")))));
        ScrollView sv = new ScrollView(this); sv.addView(root); setContentView(sv);
    }

    private void startLensSetup() {
        if (!Settings.canDrawOverlays(this)) {
            Intent overlay = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(overlay);
            Toast.makeText(this, "اسمح لميزار بالظهور فوق التطبيقات، ثم اضغط تشغيل العدسة مجدداً", Toast.LENGTH_LONG).show();
            return;
        }
        MediaProjectionManager mgr = (MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mgr.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CAPTURE) return;
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "لم يتم منح إذن التقاط الشاشة", Toast.LENGTH_SHORT).show(); return;
        }
        Intent service = new Intent(this, MizarLensService.class);
        service.putExtra(MizarLensService.EXTRA_RESULT_CODE, resultCode);
        service.putExtra(MizarLensService.EXTRA_RESULT_DATA, data);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
        Toast.makeText(this, "عدسة ميزار جاهزة. حرّك الدائرة واضغط عليها للترجمة.", Toast.LENGTH_LONG).show();
    }

    private Button button(String text, View.OnClickListener l) {
        Button btn = new Button(this); btn.setText(text); btn.setOnClickListener(l); return btn;
    }
}
