package com.example.zira;

import java.util.HashMap;
import java.util.Map;

public class ZiraCodec {
    static final String FROM = "ابتثجحخدذرزسشصضطظعغفقكلمنهوي";
    static final String TO   = "يزرسذغكثبدتجهقفعصشضطظحملوخنا";
    static final String END  = "يس";

    static final Map<String, String> SPECIAL = new HashMap<>();
    static final Map<String, String> SPECIAL_REV = new HashMap<>();
    static {
        sp("انا", "إيرون");   sp("انت", "كيسا");
        sp("هو", "أوران");    sp("هي", "أورا");
        sp("نحن", "إيرونا");  sp("هم", "أوروس");
        sp("نعم", "زيرا");    sp("لا", "ذوس");
        sp("اخ", "ذارون");    sp("ام", "ميرا");
        sp("اب", "كوراذ");    sp("ملك", "فاريكس");
        sp("صديق", "فيرذان"); sp("سر", "ميزار");
        sp("نار", "دراكيس");  sp("تنين", "فالاذ");
        sp("ابي", "ريزان");   sp("تعال", "كاروس");
        sp("روح", "زاليذ");   sp("اسكت", "سيلون");
        sp("انتبه", "ذوران"); sp("انتظر", "ميلاذ");
        sp("ماء", "أيرا");    sp("شمس", "سولان");
        sp("قمر", "لونير");   sp("بيت", "دومار");
        sp("فلوس", "أوراس");  sp("اكل", "فاميس");
        sp("خطر", "مورذ");    sp("مشكله", "ذراوس");
        sp("جوال", "تيلكس");  sp("الحين", "نوريس");
        sp("بعدين", "ثيرا");  sp("اليوم", "سولا");
        sp("بكره", "مورا");
    }

    static void sp(String ar, String z) {
        SPECIAL.put(ar, z);
        SPECIAL_REV.put(norm(z), ar);
    }

    static String norm(String s) {
        return s.replace('أ','ا').replace('إ','ا').replace('آ','ا')
                .replace('ى','ي').replace('ة','ه')
                .replace('ؤ','و').replace('ئ','ي');
    }

    public static String encodeWord(String w) {
        if (w.isEmpty()) return w;
        String n = norm(w);
        if (SPECIAL.containsKey(n)) return SPECIAL.get(n);
        StringBuilder sb = new StringBuilder();
        for (int i = n.length() - 1; i >= 0; i--) {
            char c = n.charAt(i);
            int k = FROM.indexOf(c);
            sb.append(k >= 0 ? TO.charAt(k) : c);
        }
        return sb.append(END).toString();
    }

    public static String decodeWord(String w) {
        if (w.isEmpty()) return w;
        String key = norm(w);
        if (SPECIAL_REV.containsKey(key)) return SPECIAL_REV.get(key);
        String s = w.endsWith(END) ? w.substring(0, w.length() - END.length()) : w;
        StringBuilder sb = new StringBuilder();
        for (int i = s.length() - 1; i >= 0; i--) {
            char c = s.charAt(i);
            int k = TO.indexOf(c);
            sb.append(k >= 0 ? FROM.charAt(k) : c);
        }
        return sb.toString();
    }

    public static boolean looksZira(String t) {
        int words = 0, hits = 0;
        for (String w : t.split("[\\s\u060C.\u061F?!,:;]+")) {
            if (w.isEmpty()) continue;
            words++;
            if (SPECIAL_REV.containsKey(norm(w)) || (w.endsWith(END) && w.length() > 2)) hits++;
        }
        return words > 0 && hits * 2 >= words;
    }

    public static String encodeText(String t) {
        return mapWords(t, true);
    }

    public static String decodeText(String t) {
        return mapWords(t, false);
    }

    private static String mapWords(String t, boolean enc) {
        StringBuilder out = new StringBuilder();
        StringBuilder word = new StringBuilder();
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (Character.isWhitespace(c) || "،.؟?!,:;".indexOf(c) >= 0) {
                if (word.length() > 0) {
                    out.append(enc ? encodeWord(word.toString()) : decodeWord(word.toString()));
                    word.setLength(0);
                }
                out.append(c);
            } else {
                word.append(c);
            }
        }
        if (word.length() > 0) {
            out.append(enc ? encodeWord(word.toString()) : decodeWord(word.toString()));
        }
        return out.toString();
    }
}
