package com.example.zira;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.googlecode.tesseract.android.TessBaseAPI;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Floating, user-controlled screen-reading lens. OCR is performed locally on the device. */
public class MizarLensService extends Service {
    public static final String EXTRA_RESULT_CODE = "projection_result_code";
    public static final String EXTRA_RESULT_DATA = "projection_result_data";
    private static final String CHANNEL = "mizar_lens";
    private static final int NOTIFICATION_ID = 7301;

    private WindowManager wm;
    private TextView bubble, popup;
    private WindowManager.LayoutParams bubbleLp, popupLp;
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private TessBaseAPI tess;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private int width, height, density;
    private float downX, downY;
    private int startX, startY;
    private volatile boolean processing = false;
    private MediaProjection.Callback projectionCallback;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        width = dm.widthPixels; height = dm.heightPixels; density = dm.densityDpi;
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || !intent.hasExtra(EXTRA_RESULT_DATA)) {
            stopSelf(); return START_NOT_STICKY;
        }
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, buildNotification());
        }
        Intent data = intent.getParcelableExtra(EXTRA_RESULT_DATA);
        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
        MediaProjectionManager mgr = (MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        projection = mgr.getMediaProjection(resultCode, data);
        if (projection == null) { stopSelf(); return START_NOT_STICKY; }
        projectionCallback = new MediaProjection.Callback() {
            @Override public void onStop() { stopSelf(); }
        };
        projection.registerCallback(projectionCallback, main);
        setupCapture();
        showLens();
        worker.execute(this::prepareOcr);
        return START_NOT_STICKY;
    }

    private void setupCapture() {
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3);
        virtualDisplay = projection.createVirtualDisplay("MizarLens", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader.getSurface(), null, main);
    }

    private void showLens() {
        bubble = new TextView(this);
        bubble.setText("م"); bubble.setTextColor(Color.WHITE); bubble.setTextSize(22);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL); circle.setColor(0xFF176FB5); circle.setStroke(dp(2), Color.WHITE);
        bubble.setBackground(circle);
        bubbleLp = new WindowManager.LayoutParams(dp(58), dp(58),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START; bubbleLp.x = width / 2; bubbleLp.y = height / 3;
        wm.addView(bubble, bubbleLp);

        popup = new TextView(this);
        popup.setText("اضغط العدسة لترجمة النص القريب منها"); popup.setTextColor(Color.WHITE);
        popup.setTextSize(14); popup.setPadding(dp(12), dp(9), dp(12), dp(9)); popup.setGravity(Gravity.CENTER);
        popup.setTextDirection(View.TEXT_DIRECTION_RTL);
        GradientDrawable panel = new GradientDrawable(); panel.setColor(0xEE20232B);
        panel.setCornerRadius(dp(12)); panel.setStroke(dp(1), 0xFF64B5F6); popup.setBackground(panel);
        popupLp = new WindowManager.LayoutParams(Math.min(dp(280), width - dp(20)),
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        popupLp.gravity = Gravity.TOP | Gravity.START;
        popupLp.x = Math.max(dp(6), bubbleLp.x - dp(100)); popupLp.y = bubbleLp.y + dp(66);
        wm.addView(popup, popupLp);

        bubble.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getRawX(); downY = e.getRawY(); startX = bubbleLp.x; startY = bubbleLp.y;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    bubbleLp.x = startX + (int)(e.getRawX() - downX);
                    bubbleLp.y = startY + (int)(e.getRawY() - downY);
                    clampBubble(); wm.updateViewLayout(bubble, bubbleLp); positionPopup(); return true;
                case MotionEvent.ACTION_UP:
                    if (Math.abs(e.getRawX() - downX) < dp(8) && Math.abs(e.getRawY() - downY) < dp(8)) captureAndTranslate();
                    return true;
            }
            return true;
        });
    }

    private void clampBubble() {
        bubbleLp.x = Math.max(0, Math.min(width - dp(58), bubbleLp.x));
        bubbleLp.y = Math.max(0, Math.min(height - dp(58), bubbleLp.y));
    }

    private void positionPopup() {
        popupLp.x = Math.max(dp(6), Math.min(width - dp(286), bubbleLp.x - dp(110)));
        popupLp.y = bubbleLp.y + dp(64);
        if (popupLp.y > height - dp(170)) popupLp.y = Math.max(dp(8), bubbleLp.y - dp(150));
        wm.updateViewLayout(popup, popupLp);
    }

    private void captureAndTranslate() {
        if (processing) return;
        if (tess == null) { popup.setText("محرك القراءة العربية لا يزال قيد التجهيز…"); return; }
        processing = true; popup.setText("جارٍ قراءة النص…");
        // Copy coordinates before leaving the UI thread; the user may keep moving the lens.
        final int centerX = bubbleLp.x + dp(29), centerY = bubbleLp.y + dp(29);
        worker.execute(() -> {
            Bitmap frame = acquireFrame();
            if (frame == null) { showResult("تعذر التقاط الشاشة. حاول مرة أخرى."); processing = false; return; }
            int cropW = Math.min(dp(320), frame.getWidth());
            int cropH = Math.min(dp(190), frame.getHeight());
            int left = Math.max(0, Math.min(frame.getWidth() - cropW, centerX - cropW / 2));
            int top = Math.max(0, Math.min(frame.getHeight() - cropH, centerY - cropH / 2));
            Bitmap crop = Bitmap.createBitmap(frame, left, top, cropW, cropH);
            frame.recycle();
            try {
                tess.setImage(crop);
                String recognized = tess.getUTF8Text();
                String text = recognized == null ? "" : recognized.trim();
                String translated = text.isEmpty()
                    ? "لم أتعرف على نص. حرّك العدسة فوق الكلمات وحاول مجدداً."
                    : ZiraCodec.decodeText(text);
                showResult(translated);
            } catch (Exception ex) {
                showResult("حدث خطأ أثناء قراءة النص.");
            } finally {
                crop.recycle(); processing = false;
            }
        });
    }

    private Bitmap acquireFrame() {
        for (int i = 0; i < 10; i++) {
            Image image = null;
            try {
                image = imageReader.acquireLatestImage();
                if (image != null) {
                    Image.Plane plane = image.getPlanes()[0];
                    ByteBuffer buffer = plane.getBuffer();
                    int pixelStride = plane.getPixelStride();
                    int rowStride = plane.getRowStride();
                    int rowPadding = rowStride - pixelStride * width;
                    Bitmap padded = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888);
                    buffer.rewind(); padded.copyPixelsFromBuffer(buffer);
                    Bitmap result = Bitmap.createBitmap(padded, 0, 0, width, height);
                    padded.recycle(); return result;
                }
                Thread.sleep(100);
            } catch (Exception ignored) {
            } finally { if (image != null) image.close(); }
        }
        return null;
    }

    private void prepareOcr() {
        try {
            File dataDir = new File(getFilesDir(), "tessdata");
            if (!dataDir.exists() && !dataDir.mkdirs()) throw new Exception("Cannot create OCR folder");
            File model = new File(dataDir, "ara.traineddata");
            if (!model.exists() || model.length() < 1000000) {
                showResult("يتم تجهيز نموذج القراءة العربية لأول مرة…");
                URL url = new URL("https://github.com/tesseract-ocr/tessdata_fast/raw/refs/heads/main/ara.traineddata");
                HttpURLConnection connection = (HttpURLConnection)url.openConnection();
                connection.setConnectTimeout(15000); connection.setReadTimeout(45000);
                connection.setInstanceFollowRedirects(true);
                try (InputStream in = connection.getInputStream(); FileOutputStream out = new FileOutputStream(model)) {
                    byte[] bytes = new byte[8192]; int count;
                    while ((count = in.read(bytes)) != -1) out.write(bytes, 0, count);
                } finally { connection.disconnect(); }
            }
            TessBaseAPI api = new TessBaseAPI();
            if (!api.init(getFilesDir().getAbsolutePath(), "ara")) {
                api.recycle(); showResult("تعذر تشغيل قارئ العربية. أوقف العدسة وشغّلها مجدداً."); return;
            }
            tess = api; showResult("العدسة جاهزة. حرّكها فوق النص واضغط عليها.");
        } catch (Exception e) {
            showResult("تعذر تجهيز نموذج العربية. تحقق من الإنترنت ثم أعد تشغيل العدسة.");
        }
    }

    private void showResult(String text) {
        main.post(() -> { if (popup != null) popup.setText(text); });
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private Notification buildNotification() {
        Intent stop = new Intent(this, MizarLensService.class);
        PendingIntent pending = PendingIntent.getService(this, 1, stop,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return builder.setContentTitle("عدسة ميزار تعمل")
            .setContentText("اضغط العدسة العائمة لقراءة النص وترجمته")
            .setSmallIcon(android.R.drawable.ic_menu_search).setOngoing(true)
            .addAction(new Notification.Action.Builder(null, "إيقاف", pending).build()).build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "عدسة ميزار", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    @Override public void onDestroy() {
        if (bubble != null) try { wm.removeView(bubble); } catch (Exception ignored) {}
        if (popup != null) try { wm.removeView(popup); } catch (Exception ignored) {}
        if (virtualDisplay != null) virtualDisplay.release();
        if (imageReader != null) imageReader.close();
        if (projection != null) { if (projectionCallback != null) projection.unregisterCallback(projectionCallback); projection.stop(); }
        if (tess != null) tess.recycle();
        worker.shutdownNow(); super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
