package com.example.zira;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ZiraIME extends InputMethodService {
    private final StringBuilder buf = new StringBuilder();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean secret = true;
    private Button modeBtn;
    private GradientDrawable modeBg;
    private TextView strip;
    private ClipboardManager cm;
    private ClipboardManager.OnPrimaryClipChangedListener clipListener;
    private float d = 3f;

    private static final String HINT = "انسخ رسالة مشفرة وتظهر ترجمتها هنا";
    private static final String DIGITS = "١٢٣٤٥٦٧٨٩٠";
    private static final String[] ROWS = {
        "ضصثقفغعهخحج",
        "شسيبلاتنمكط",
        "ذظزرودئءؤ"
    };

    @Override
    public void onCreate() {
        super.onCreate();
        d = getResources().getDisplayMetrics().density;
        cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        clipListener = this::refreshClip;
        cm.addPrimaryClipChangedListener(clipListener);
    }

    @Override
    public void onDestroy() {
        if (cm != null && clipListener != null) cm.removePrimaryClipChangedListener(clipListener);
        super.onDestroy();
    }

    private int dp(int v) { return (int) (v * d + 0.5f); }

    @Override
    public View onCreateInputView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF15151B);
        root.setPadding(dp(3), dp(6), dp(3), dp(6));

        strip = new TextView(this);
        strip.setTextSize(16);
        strip.setTextColor(0xFF9FD3FF);
        strip.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        strip.setMinHeight(dp(44));
        strip.setMaxLines(3);
        strip.setPadding(dp(12), dp(6), dp(12), dp(6));
        GradientDrawable sbg = new GradientDrawable();
        sbg.setColor(0xFF23232D);
        sbg.setCornerRadius(dp(8));
        strip.setBackground(sbg);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        sp.setMargins(dp(3), 0, dp(3), dp(4));
        root.addView(strip, sp);
        refreshClip();

        LinearLayout dr = newRow(44);
        for (char ch : DIGITS.toCharArray()) {
            final char c = ch;
            dr.addView(key(String.valueOf(c), 1f, 18, v -> digit(c)));
        }
        root.addView(dr);

        for (int i = 0; i < ROWS.length; i++) {
            LinearLayout r = newRow(56);
            for (char ch : ROWS[i].toCharArray()) {
                final char c = ch;
                r.addView(key(String.valueOf(c), 1f, 22, v -> typeChar(c)));
            }
            if (i == ROWS.length - 1) {
                Button bk = key("⌫", 1.6f, 22, null);
                final Runnable rep = new Runnable() {
                    @Override public void run() {
                        backspace();
                        handler.postDelayed(this, 60);
                    }
                };
                bk.setOnTouchListener((v, e) -> {
                    switch (e.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                            backspace();
                            handler.postDelayed(rep, 400);
                            return true;
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            handler.removeCallbacks(rep);
                            return true;
                    }
                    return false;
                });
                r.addView(bk);
            }
            root.addView(r);
        }

        LinearLayout last = newRow(56);
        last.addView(key("🌐", 1.2f, 18, v -> ((InputMethodManager)
            getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker()));
        modeBtn = key("سري", 1.6f, 16, v -> toggleMode());
        modeBg = (GradientDrawable) modeBtn.getBackground();
        updateMode();
        last.addView(modeBtn);
        last.addView(key("فك", 1.2f, 16, v -> decodeBeforeCursor()));
        last.addView(key("،", 1f, 20, v -> punct("،")));
        last.addView(key("مسافة", 3f, 16, v -> space()));
        last.addView(key(".", 1f, 20, v -> punct(".")));
        last.addView(key("؟", 1f, 20, v -> punct("؟")));
        last.addView(key("↵", 1.4f, 20, v -> enter()));
        root.addView(last);
        return root;
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        refreshClip();
    }

    private LinearLayout newRow(int heightDp) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(heightDp)));
        return r;
    }

    private Button key(String label, float weight, int sp, final View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(sp);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setMinimumHeight(0);
        b.setMinimumWidth(0);
        b.setPadding(0, 0, 0, 0);
        b.setStateListAnimator(null);
        b.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF33333F);
        g.setCornerRadius(dp(8));
        b.setBackground(g);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.MATCH_PARENT, weight);
        p.setMargins(dp(2), dp(3), dp(2), dp(3));
        b.setLayoutParams(p);
        if (l != null) {
            b.setOnClickListener(v -> {
                v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                l.onClick(v);
            });
        }
        return b;
    }

    private void refreshClip() {
        if (strip == null || cm == null) return;
        String shown = null;
        try {
            ClipData cd = cm.getPrimaryClip();
            if (cd != null && cd.getItemCount() > 0) {
                CharSequence t = cd.getItemAt(0).coerceToText(this);
                if (t != null) {
                    String s = t.toString().trim();
                    if (s.length() > 0 && ZiraCodec.looksZira(s)) {
                        shown = ZiraCodec.decodeText(s);
                    }
                }
            }
        } catch (Exception ignored) { }
        if (shown != null) {
            strip.setTextColor(0xFF9FD3FF);
            strip.setText(shown);
        } else {
            strip.setTextColor(0xFF77778A);
            strip.setText(HINT);
        }
    }

    private void typeChar(char c) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (secret) {
            buf.append(c);
            ic.setComposingText(buf, 1);
        } else {
            ic.commitText(String.valueOf(c), 1);
        }
    }

    private void digit(char c) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        flush();
        ic.commitText(String.valueOf(c), 1);
    }

    private void flush() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null || buf.length() == 0) return;
        ic.commitText(ZiraCodec.encodeWord(buf.toString()), 1);
        buf.setLength(0);
    }

    private void space() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        flush();
        ic.commitText(" ", 1);
    }

    private void punct(String p) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        flush();
        ic.commitText(p, 1);
    }

    private void enter() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        flush();
        ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER));
        ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER));
    }

    private void backspace() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (buf.length() > 0) {
            buf.deleteCharAt(buf.length() - 1);
            if (buf.length() == 0) ic.commitText("", 1);
            else ic.setComposingText(buf, 1);
        } else {
            ic.deleteSurroundingText(1, 0);
        }
    }

    private void toggleMode() {
        flush();
        secret = !secret;
        updateMode();
    }

    private void updateMode() {
        if (modeBtn == null) return;
        modeBtn.setText(secret ? "سري" : "عادي");
        if (modeBg != null) modeBg.setColor(secret ? 0xFF2E7D32 : 0xFF55555F);
    }

    private void decodeBeforeCursor() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        flush();
        CharSequence t = ic.getTextBeforeCursor(500, 0);
        if (t == null || t.length() == 0) return;
        strip.setTextColor(0xFF9FD3FF);
        strip.setText(ZiraCodec.decodeText(t.toString()));
    }

    @Override
    public void onFinishInputView(boolean finishingInput) {
        buf.setLength(0);
        super.onFinishInputView(finishingInput);
    }
}
